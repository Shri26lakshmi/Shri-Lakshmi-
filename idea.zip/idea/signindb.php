<?php
$server="localhost";
$user="root";
$password="";
$db="signin";
$conn=mysqli_connect($server,$user,$password,$db);
if($conn)
{
echo "Connection Successful";
}
else
{
echo "Connection Failure";
}
?>