$(document).ready(function() {
  $('#forgotPasswordForm').submit(function(event) {
    event.preventDefault();
    var email = $('#email').val();

    // Send AJAX request to the server
    $.ajax({
      url: 'forgot_password.php',
      method: 'POST',
      data: { email: email },
      success: function(response) {
        // Display response message
        $('#response').html(response);
      }
    });
  });
});