<?php
include "idea.php";
$name=$_POST['name'];
$email=$_POST['email'];
$pass=$_POST['password'];
$telephone=$_POST['telephone'];
$address=$_POST['address'];
$sql="insert into user(name,email,password,telephone,address)values('$name','$email','$pass','$telephone','$address')";
if (mysqli_query($conn,$sql))
{
echo "success";
header('refresh:1,url=loginafter.html');
}
else
{
echo "failure";
}
mysqli_close($conn);
?>
