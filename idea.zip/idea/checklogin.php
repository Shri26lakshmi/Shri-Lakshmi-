<html>
<?php
include "idea.php";
$name=$_POST['name'];
$password=$_POST['password'];
$sql="select"from login where name='$name' and password='$password'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)==1)
{
echo"login Successful";
}
else
{
echo"invalid login";
}
mysqli_close($conn);
?>
</html>
