<?php
include "signin.php";
$username=$_POST['username'];
$password=$_POST['password'];
$sql="select * from register where username='$username' and password='$password'";
if(mysqli_query($conn,$sql))
{
	echo "login successful";
	header('refresh:1,url=home.php');
}
else
{
echo "invalid login";
header('refresh:1,url=reg.php');
}
mysqli_close($conn);
?>