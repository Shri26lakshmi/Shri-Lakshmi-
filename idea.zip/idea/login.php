<?php
include "signindb.php";
$username=$_POST['username'];
$password=$_POST['password'];
$sql="insert into login(username,password)values('$username','$password')";
if (mysqli_query($conn,$sql))
{
echo "success";

}
else
{
echo "failure";
}
mysqli_close($conn);
?>
